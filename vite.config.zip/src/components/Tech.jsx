import React, { useEffect, useState } from "react";
import "../App.css";
import Header from "./Header";

const Tech = () => {
  const [data, setData] = useState([]);

  const GetBlogs = async () => {
    try {
      const response = await fetch("http://localhost:4000/api/auth/getblogs", {
        method: "GET",
        redirect: "follow",
      });
      const result = await response.json();

      if (result?.blogs) {
        setData(result.blogs);
      } else {
        console.error("Failed to fetch blogs:", result?.message);
      }
    } catch (error) {
      console.error("API Error:", error);
    }
  };

  useEffect(() => {
    GetBlogs();
  }, []);

  return (
    <>
    <Header/>
      <div style={{ padding: "20px" }}>
        <div className="container-fluid px-5">
          <div className="row">
            {data.length > 0 ? (
              data.map((res) => (
                <div
                  className="col-lg-4 col-md-6 col-sm-12 mb-4"
                  key={res?._id}
                >
                  <div
                    className="card bg-dark text-white shadow-lg rounded"
                    style={{
                      height: "500px",
                      overflow: "hidden",
                      display: "flex",
                      flexDirection: "column",
                      border: "1px solid #333",
                    }}
                  >
                    <img
                      src={`http://localhost:4000/${res?.img}`}
                      alt="Blog Thumbnail"
                      style={{
                        width: "100%",
                        height: "240px",
                        objectFit: "cover",
                      }}
                    />
                    <div
                      className="card-body"
                      style={{
                        overflowY: "auto",
                        padding: "10px",
                        flex: 1,
                      }}
                    >
                      <h6 style={{ marginBottom: "8px" }}>
                        <strong>Title:</strong> {res?.title}
                      </h6>
                      <h6 style={{ marginBottom: "8px" }}>
                        <strong>Short Description:</strong>{" "}
                        {res?.shortdescription}
                      </h6>
                      <h6 style={{ marginBottom: "8px" }}>
                        <strong>Full Description:</strong>{" "}
                        {res?.fulldescription}
                      </h6>
                      <h6 style={{ marginBottom: "8px" }}>
                        <strong>Facebook:</strong> {res?.facebook}
                      </h6>
                      <h6 style={{ marginBottom: "8px" }}>
                        <strong>Threads:</strong> {res?.threads}
                      </h6>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <h4 className="text-white mt-5 pt-5 text-center">
                No blogs found.
              </h4>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Tech;

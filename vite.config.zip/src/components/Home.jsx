import React, { useEffect, useState } from "react";
import "./all.css";
import solotrip from "../components/images/Solotrip.png";
// import one from '../components/images/1.webp';
// import two from '../components/images/2.png';
// import three from '../components/images/3.png';
// import four from '../components/images/4.png';
import Header from "./Header";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();

  const [data, setData] = useState([]);

  const GetBlogs = async () => {
    try {
      const requestOptions = {
        method: "GET",
        redirect: "follow",
      };

      const response = await fetch(
        "http://localhost:4000/api/auth/getblogs",
        requestOptions
      );
      const result = await response.json();

      if (result?.blogs) {
        setData(result.blogs); // ✅ Correct condition
      } else {
        console.error("Failed to fetch blogs:", result?.message);
      }
    } catch (error) {
      console.error("API Error:", error);
    }
  };

  useEffect(() => {
    GetBlogs();
  }, []);

  // const stories = [
  //   {
  //     number: "1",
  //     title: "The future of BMW is being built at a battery factory in Germany",
  //     author: "ALEX HEATH",
  //     time: "6:16 AM GMT-5:30",
  //     imgSrc: one, // Corrected: Removed extra {}
  //   },
  //   {
  //     number: "2",
  //     title: "Maya Bay In Thailand: The Beach Is Open! (Phi Phi Leh)",
  //     author: "VERGE STAFF",
  //     time: "3:04 AM GMT-5:30",
  //     imgSrc: two, // Corrected: Removed extra {}
  //   },
  //   {
  //     number: "3",
  //     title: "How To Visit The Tikal Mayan Ruins In Guatemala (+Map)",
  //     author: "JESS WEATHERBED",
  //     time: "2:41 AM GMT-5:30",
  //     imgSrc: three, // Corrected: Removed extra {}
  //   },
  //   {
  //     number: "3",
  //     title: "10 Day Morocco Itinerary: Marrakesh, Fes, Sahara & Toubkal",
  //     author: "JESS WEATHERBED",
  //     time: "2:41 AM GMT-5:30",
  //     imgSrc: four, // Corrected: Removed extra {}
  //   },
  //   {
  //     number: "3",
  //     title: "How To Visit The Tikal Mayan Ruins In Guatemala (+Map)",
  //     author: "JESS WEATHERBED",
  //     time: "2:41 AM GMT-5:30",
  //     imgSrc: three, // Corrected: Removed extra {}
  //   },
  // ];

  return (
    <div className="text-light">
      <Header />

      <div className="container">
        <div className="row">
          <div className="col-lg-8">
            <div className="main-content">
              <div className="featured-article">
                <div className="featured-image-container">
                  <img
                    src={solotrip}
                    alt="Feature Image"
                    className="featured-image"
                  />
                </div>
                <div className="top-news">
                  <a href="#" className="featured-title">
                    Daredevil: Born Again is a rough reboot with a promising
                    future
                  </a>
                  <p className="featured-subtitle">
                    Disney Plus’ new Daredevil series is an uneven reboot that’s
                    fighting to leave its past behind.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-4">
            <div className="top-stories ">
              <h2 className="top-stories-header">Top Stories</h2>
              <ol className="story-list">
                {data?.slice(0, 5).map((res, index) => {
                  return (
                    <li
                      onClick={() => navigate(`/blogs/${res?._id}`)}
                      style={{ cursor: "pointer" }}
                      className="story-item d-flex align-items-center mb-3"
                      key={index + 1}
                    >
                      <div className="story-number me-3">{index + 1}</div>

                      <div className="story-content flex-grow-1">
                        <h3 className="story-title mb-1">{res?.title}</h3>
                        {/* <h3 className="story-title">{res?.shortdescription}</h3> */}
                        <div className="story-meta">
                          <span className="story-author">{res?.author}</span>
                          <p className="story-time">
                            <span style={{ color: "#32a868" }}>
                              Kristal Radika{" "}
                            </span>
                            <span
                              style={{
                                textTransform: "capitalize",
                                fontSize: "10px",
                                paddingLeft: "15px",
                              }}
                            >
                              Two Hours Ago
                            </span>
                          </p>
                        </div>
                      </div>

                      <div
                        className="story-thumbnail"
                        style={{
                          width: "80px",
                          height: "80px",
                          overflow: "hidden",
                          borderRadius: "8px",
                          flexShrink: 0,
                        }}
                      >
                        <img
                          src={`http://localhost:4000/${res?.img}`}
                          alt={res?.title}
                          style={{
                            width: "100%",
                            height: "100%",
                            objectFit: "cover",
                          }}
                        />
                      </div>
                    </li>
                  );
                })}

                {/* {stories.map((story, index) => (
                    <li onClick={() => navigate(`/blogs`)} style={{cursor:"pointer"}} className="story-item" key={index}>
                      <div className="story-number">{story.number}</div>
                      <div className="story-content">
                        <h3 className="story-title">{story.title}</h3>
                        <div className="story-meta">
                          <span className="story-author">{story.author}</span>
                          <span className="story-time">{story.time}</span>
                        </div>
                      </div>
                      <div className="story-thumbnail">
                        <img src={story.imgSrc} alt={story.title} />
                      </div>
                    </li>
                  ))} */}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

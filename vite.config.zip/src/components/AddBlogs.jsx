import React, { useRef, useState } from "react";
import "./AddBlogs.css";
import JoditEditor from "jodit-react";
import { NavLink, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import logo from "../components/images/logo.png";

const AddBlogs = () => {
  const [title, setTitle] = useState("");
  const [shortDescription, setShortDescription] = useState("");
  const [content, setContent] = useState("");
  const [facebook, setFacebook] = useState("");
  const [thread, setThread] = useState("");
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);

  const fileInputRef = useRef(null);
  const editor = useRef(null);
  const navigate = useNavigate();

  // Image change handler
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file)); // Show preview
    }
  };

  // File select trigger
  const triggerFileSelect = () => {
    fileInputRef.current.value = "";
    fileInputRef.current.click();
  };

  const CreateApi = () => {
    try {
      const formdata = new FormData();
      formdata.append("img", fileInputRef.current.files[0]);
      formdata.append("title", title);
      formdata.append("shortdescription", shortDescription);
      formdata.append("fulldescription", content);
      formdata.append("facebook", facebook);
      formdata.append("threads", thread);

      const requestOptions = {
        method: "POST",
        body: formdata,
        redirect: "follow",
      };

      fetch("http://localhost:4000/api/auth/addblogs", requestOptions)
        .then((response) => response.json())
        .then((result) => {
          if (result) {
            toast.success("Blog Created Successfully!");
            // ✅ Clear form fields
            setTitle("");
            setShortDescription("");
            setContent("");
            setFacebook("");
            setThread("");
            setImage(null);
            fileInputRef.current.value = "";

            // Show loader before navigating
            setLoading(true);
            setTimeout(() => {
              setLoading(false);
              navigate("/");
            }, 1000);
          } else {
            toast.error(result?.message || "Something went wrong!");
          }
        })
        .catch((error) => {
          console.error(error);
          toast.error("Error occurred while creating blog!");
        });
    } catch (error) {
      console.error(error);
      toast.error("Unexpected error!");
    }
  };

  // Custom Loader Styling (No Tailwind)
  if (loading) {
    return (
      <div
        style={{
          height: "100vh",
          width: "100vw",
          backgroundColor: "#000",
          color: "#fff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
        }}
      >
        <div style={{ position: "relative", width: "150px", height: "150px" }}>
          <div
            style={{
              border: "10px solid #f3f3f3",
              borderTop: "10px solid #3498db",
              borderRadius: "50%",
              width: "150px",
              height: "150px",
              animation: "spin 1s linear infinite",
            }}
          ></div>
          {/* Center Image inside the spinner */}
          <img
            src={logo}
            alt="Loading"
            style={{
              width: "80px",
              height: "80px",
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
            }}
          />
        </div>
  
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }
  
  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-10 m-auto">
            <div className="blog-form-card fade-in">
              <div className="mb-4 d-flex justify-content-between">
                <h1>Create New Blog</h1>
                <NavLink to="/allblogs">
                  <button className="submit-button">All Blogs</button>
                </NavLink>
              </div>

              <div className="form-group">
                <label className="form-label">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="form-input"
                  placeholder="Enter blog title"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Facebook</label>
                <input
                  type="text"
                  value={facebook}
                  onChange={(e) => setFacebook(e.target.value)}
                  className="form-input"
                  placeholder="Enter Facebook Link"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Thread</label>
                <input
                  type="text"
                  value={thread}
                  onChange={(e) => setThread(e.target.value)}
                  className="form-input"
                  placeholder="Enter Thread Link"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Short Description</label>
                <textarea
                  value={shortDescription}
                  onChange={(e) => setShortDescription(e.target.value)}
                  className="form-input"
                  placeholder="Write a brief description"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Image Thumbnail</label>
                <div
                  className="image-upload relative flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-4 cursor-pointer hover:bg-gray-100"
                  onClick={triggerFileSelect}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageChange}
                    style={{ opacity: "0" }}
                  />
                  {image ? (
                    <>
                      <img
                        src={image}
                        alt="Uploaded"
                        className="w-32 h-32 object-cover rounded-md"
                        style={{ width: "100%" }}
                      />
                      <div className="flex gap-2 mt-2">
                        <button
                          className="btn btn-primary"
                          onClick={(e) => {
                            e.stopPropagation();
                            setImage(null);
                          }}
                        >
                          Remove
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="cursor-pointer flex flex-col items-center">
                      <svg
                        className="mx-auto h-12 w-12 text-gray-500"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        style={{ width: "10%" }}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M12 4v16m8-8H4"
                        />
                      </svg>
                      <br />
                      <span className="text-gray-500 mt-2">
                        Click to upload image
                      </span>
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Content</label>
                <JoditEditor
                  ref={editor}
                  value={content}
                  tabIndex={1}
                  onBlur={(newContent) => setContent(newContent)}
                  onChange={(newContent) => setContent(newContent)}
                />
              </div>

              <div style={{ textAlign: "right" }}>
                <button
                  type="submit"
                  className="submit-button"
                  onClick={CreateApi}
                >
                  Publish Blog
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddBlogs;

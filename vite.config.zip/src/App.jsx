import React from "react";
import Home from "./components/Home";
import Login from "./components/Login";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SignUp from "./components/SignUp";
// import ProfilePage from './components/ProfilePage';
import { ToastContainer } from "react-toastify";
import AccountProfile from "./components/AccountProfile";
import Blogs from "./components/Blogs";
import AddBlogs from "./components/AddBlogs";
import AllBlogs from "./AllBlogs";
import Tech from "./components/Tech";
import ProtectedRoute from "./components/utils/ProtectedRoute";

const App = () => {
  return (
    <div>
      <ToastContainer />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />.
          <Route element={<ProtectedRoute />}>
            <Route path="/profile" element={<AccountProfile />} />
            <Route path="/tech" element={<Tech />} />
            <Route path="/blogs/:id" element={<Blogs />} />
            <Route path="/allblogs" element={<AllBlogs />} />
            <Route path="/add/blogs" element={<AddBlogs />} />
          </Route>
          <Route path="/register" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
